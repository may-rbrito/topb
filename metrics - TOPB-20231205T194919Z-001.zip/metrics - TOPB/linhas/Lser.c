#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <sys/time.h>
#include <omp.h>

// gcc -fopenmp Lser.c -o Lser -lm

void bubble_sort(double *matriz, int tam) {
    int i, j;
    double aux;

    for (i = tam - 1; i > 0; i--) {
        for (j = 0; j < i; j++) {

            if (matriz[j] > matriz[j + 1]) {
                aux = matriz[j];
                matriz[j] = matriz[j + 1];
                matriz[j + 1] = aux;
            }
        }
    }
}

void ordena_linhas(double *matriz, int lin, int col) {
    int i;

    for (i = 0; i < lin; i++) {
        bubble_sort(&matriz[i * col], col);
    }
}

void calcula_media(double *matriz, double *vet, int lin, int col) {
    int i, j;
    for (i = 0; i < lin; i++) {
        double soma = 0;
        for (j = 0; j < col; j++) {
            soma += matriz[i * col + j];
        }
        vet[i] = soma / col;
    }
}

void calcula_media_harmonica(double *matriz, double *vet, int lin, int col) {
    int i, j;
    for (i = 0; i < lin; i++) {
        double soma = 0;
        for (j = 0; j < col; j++) {
            soma += 1 / matriz[i * col + j];
        }
        vet[i] = col / soma;
    }
}

void calcula_mediana(double *matriz, double *vet, int lin, int col) {
    int i;
    for (i = 0; i < lin; i++) {
        if (col % 2 == 0) {
            // Se o número de colunas for par, calcula a média dos dois valores do meio
            int meio1 = col / 2 - 1;
            int meio2 = col / 2;
            vet[i] = (matriz[i * col + meio1] + matriz[i * col + meio2]) / 2;
        } else {
            // Se o número de colunas for ímpar, pega o valor do meio
            int meio = col / 2;
            vet[i] = matriz[i * col + meio];
        }
    }
} 

double moda_aux(double *matriz, int col) {
    int i, j;
    double *cont;
    cont = (double *)malloc(col * sizeof(double));
    float conta = 0, moda = 0;

    for (i = 0; i < col; i++) {
        for (j = i + 1; j < col; j++) {
            if (matriz[i] == matriz[j]) {
                cont[i]++;
                if (cont[i] > conta) {
                    conta = cont[i];
                    moda = matriz[i];
                }
            }
        }
        cont[i] = 0;
    }
    free(cont);
    if (conta == 0) {
        return -1;
    } else {
        return moda;
    }
}

void calcula_moda(double *matriz, double *moda, int lin, int col) {
    int i;
   
    for (i = 0; i < lin; i++) {
        moda[i] = moda_aux(matriz + (i * col), col);
    }
}

void calcula_variancia(double *matriz, double *media, double *variancia, int lin, int col) {
    int i, j;
    for (i = 0; i < lin; i++) {
        double soma = 0;
        for (j = 0; j < col; j++) {
            soma += pow((matriz[i * col + j] - media[i]), 2);
        }
        variancia[i] = soma / (col - 1);
    }
}

void calcula_desvio_padrao(double *variancia, double *dp, int lin) {
    int i;
    for (i = 0; i < lin; i++) {
        dp[i] = sqrt(variancia[i]);
    }
}

void calcula_coeficiente_variacao(double *media, double *dp, double *cv, int lin) {
    int i;
    for (i = 0; i < lin; i++) {
        cv[i] = dp[i] / media[i];
    }
}

int main(int argc, char **argv) {

    FILE *arquivo = fopen("input", "r");

    int lin, col, i, j; // Define as variáveis de índices e dimensões
    double *matriz, *mediana, *media, *media_har, *moda, *variancia, *dp, *cv; // Define a matriz (forma linear), vetores de medidas estatísticas

    fscanf(arquivo, "%d ", &lin); // Lê a quantidade de linhas da matriz
    fscanf(arquivo, "%d\n", &col); // Lê a quantidade de colunas da matriz

    // Alocações
    matriz = (double *)malloc(lin * col * sizeof(double)); // Aloca a matriz
    media = (double *)malloc(lin * sizeof(double)); // Aloca o vetor de media
    media_har = (double *)malloc(lin * sizeof(double)); // Aloca o vetor de media harmônica
    mediana = (double *)malloc(lin * sizeof(double)); // Aloca o vetor de mediana
    moda = (double *)malloc(lin * sizeof(double)); // Aloca o vetor de moda
    variancia = (double *)malloc(lin * sizeof(double)); // Aloca o vetor de variância
    cv = (double *)malloc(lin * sizeof(double)); // Aloca o vetor de coeficiente de variação
    dp = (double *)malloc(lin * sizeof(double)); // Aloca o vetor de desvio padrão

    for (i = 0; i < lin; i++) {
        printf("\n");
        for (j = 0; j < col; j++) {
            fscanf(arquivo, "%lf ", &(matriz[i * col + j])); // Lê os dados em uma matriz de entrada
            printf("%f ", matriz[i * col + j]);
        }
    }
    double start_time, end_time;
    start_time = omp_get_wtime();
    
    calcula_media(matriz, media, lin, col);
    calcula_media_harmonica(matriz, media_har, lin, col);   
    ordena_linhas(matriz, lin, col);
    calcula_mediana(matriz, mediana, lin, col);
    calcula_moda(matriz, moda, lin, col);
    calcula_variancia(matriz, media, variancia, lin, col);
    calcula_desvio_padrao(variancia, dp, lin);
    calcula_coeficiente_variacao(media, dp, cv, lin);

    end_time = omp_get_wtime();
    printf("%f\n", end_time - start_time);
/*

    printf("\n-MÉDIA- \n");
    for (i = 0; i < lin; i++)
        printf("%.1lf\n", media[i]);

    printf("\n-MÉDIA HARMÔNICA- \n");
    for (i = 0; i < lin; i++)
        printf("%.1lf\n", media_har[i]);

    printf("\n-MEDIANA- \n");
    for (i = 0; i < lin; i++)
        printf("%.1lf\n", mediana[i]);

    printf("\n-MODA- \n");
    for (i = 0; i < lin; i++)
        printf("%.1lf\n", moda[i]);

    printf("\n-VARIÂNCIA- \n");
    for (i = 0; i < lin; i++)
        printf("%.1lf\n", variancia[i]);

    printf("\n-DESVIO PADRÃO- \n");
    for (i = 0; i < lin; i++)
        printf("%.1lf\n", dp[i]);

    printf("\n-COEFICIENTE DE VARIÂNCIA- \n");
    for (i = 0; i < lin; i++)
        printf("%.1lf\n", cv[i]);
*/

    // Desaloca memória
    free(matriz);
    free(media);
    free(media_har);
    free(mediana);
    free(moda);
    free(variancia);
    free(dp);
    free(cv);

}
