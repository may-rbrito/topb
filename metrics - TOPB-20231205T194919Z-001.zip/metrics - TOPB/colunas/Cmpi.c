#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <sys/time.h>
#include <omp.h>
#include <mpi.h>

//mpicc -fopenmp Cmpi.c -o Cmpi -lm
//mpirun -np 8 ./Cmpi

void bubble_sort(double *matriz, int tam) {
    int i, j;
    double aux;

    for (i = tam - 1; i > 0; i--) {
        for (j = 0; j < i; j++) {
            if (matriz[j] > matriz[j + 1]) {
                aux = matriz[j];
                matriz[j] = matriz[j + 1];
                matriz[j + 1] = aux;
            }
        }
    }
}

void ordena_colunas(double *matriz, int lin, int col) {
    int i;

    for (i = 0; i < col; i++) {
        bubble_sort(&matriz[i * lin], lin);
    }
}

void calcula_media(double *matriz, double *vet, int lin, int col) {
    int i, j;
    double soma;
    for (i = 0; i < col; i++) {
        soma = 0;
        for (j = 0; j < lin; j++) {
            soma += matriz[i * lin + j];
        }
        vet[i] = soma / lin;
    }
}

void calcula_media_harmonica(double *matriz, double *vet, int lin, int col) {
    int i, j;
    double soma;
    for (i = 0; i < col; i++) {
        soma = 0;
        for (j = 0; j < lin; j++) {
            soma += (1 / (matriz[i * lin + j]));
        }
        vet[i] = lin / soma;
    }
}

void calcula_mediana(double *matriz, double *vet, int lin, int col) {  
    int i;
    for (i = 0; i < col; i++) {
        if (lin % 2 == 0) {
            // Se o número de linhas for par, calcula a média dos dois valores do meio
            int meio1 = lin / 2 - 1;
            int meio2 = lin / 2;
            vet[i] = (matriz[i * lin + meio1] + matriz[i * lin + meio2]) / 2;
        } else {
            // Se o número de linhas for ímpar, pega o valor do meio
            int meio = lin / 2;
            vet[i] = matriz[i * lin + meio];
        }
    }
}

double moda_aux(double *matriz, int lin) {
    int i, j;
    double *cont;
    cont = (double *)malloc(lin * sizeof(double));
    float conta = 0, moda = 0;

    for (i = 0; i < lin; i++) {
        for (j = i + 1; j < lin; j++) {
            if (matriz[i] == matriz[j]) {
                cont[i]++;
                if (cont[i] > conta) {
                    conta = cont[i];
                    moda = matriz[i];
                }
            }
        }
        cont[i] = 0;
    }
    free(cont);
    if (conta == 0) {
        return -1;
    } else {
        return moda;
    }
}

void calcula_moda(double *matriz, double *moda, int lin, int col) {
    int i;
    for (i = 0; i < col; i++) {
        moda[i] = moda_aux(matriz + (i * lin), lin);
    }
}

void calcula_variancia(double *matriz, double *media, double *variancia, int lin, int col) {
    int i, j;
    double soma;
    for (i = 0; i < col; i++) {
        soma = 0;
        for (j = 0; j < lin; j++) {
            soma += pow((matriz[i * lin + j] - media[i]), 2);
        }
        variancia[i] = soma / (lin - 1);
    }
}

void calcula_desvio_padrao(double *variancia, double *dp, int col) {
    int i;
    for (i = 0; i < col; i++) {
        dp[i] = sqrt(variancia[i]);
    }
}

void calcula_coeficiente_variacao(double *media, double *dp, double *cv, int col) {
    int i;
    for (i = 0; i < col; i++) {
        cv[i] = dp[i] / media[i];
    }
}

int main(int argc, char **argv) {

    int rank, processos, i, j, k, col_proc, lin, col; // Define as variáveis de índices e dimensões
    double *matriz, *mediana, *media, *media_har, *moda, *variancia, *dp, *cv; // Define a matriz (forma linear), vetores de medidas estatísticas
    double *matriz_local, *moda_local;
    double start_time, end_time;

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &processos);
    MPI_Status status;

    if (rank == 0) {
        FILE *arquivo = fopen("input", "r");
        fscanf(arquivo, "%d ", &lin); // Lê a quantidade de linhas da matriz
        fscanf(arquivo, "%d\n", &col); // Lê a quantidade de colunas da matriz

        col_proc = col / processos; // Calcula o número de colunas por processo
        
        // Alocações
        matriz = (double *)malloc(lin * col * sizeof(double)); // Aloca a matriz
        media = (double *)malloc(col * sizeof(double)); // Aloca o vetor de media
        media_har = (double *)malloc(col * sizeof(double)); // Aloca o vetor de media harmônica
        mediana = (double *)malloc(col * sizeof(double)); // Aloca o vetor de mediana
        moda = (double *)malloc(col * sizeof(double)); // Aloca o vetor de moda
        variancia = (double *)malloc(col * sizeof(double)); // Aloca o vetor de variância
        cv = (double *)malloc(col * sizeof(double)); // Aloca o vetor de coeficiente de variação
        dp = (double *)malloc(col * sizeof(double)); // Aloca o vetor de desvio padrão

        // Leitura da matriz a partir do arquivo
        for (i = 0; i < lin; i++) {
            for (j = 0; j < col; j++) {
                fscanf(arquivo, "%lf ", &(matriz[j * lin + i]));
            }
        }

        fclose(arquivo);

        start_time = omp_get_wtime();
        // Divide a matriz entre os processos
        for (i = 1; i < processos; i++) {
            MPI_Send(&col_proc, 1, MPI_INT, i, 0, MPI_COMM_WORLD);
            MPI_Send(&lin, 1, MPI_INT, i, 0, MPI_COMM_WORLD);
            MPI_Send(&(matriz[i * col_proc * lin]), col_proc * lin, MPI_DOUBLE, i, 0, MPI_COMM_WORLD);
        }

        // Atribui a porção da matriz ao processo 0
        matriz_local = (double *)malloc(col_proc * lin * sizeof(double));
        for (i = 0; i < lin * col_proc; i++) {
            matriz_local[i] = matriz[i];
        }

    } else {
        // Recebe os dados do processo 0
        MPI_Recv(&col_proc, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, &status);
        MPI_Recv(&lin, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, &status);
        matriz_local = (double *)malloc(col_proc * lin * sizeof(double));
        MPI_Recv(matriz_local, col_proc * lin, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD, &status);
    }

    moda_local = (double *)malloc(col_proc * sizeof(double));
    ordena_colunas(matriz_local, lin, col_proc);
    calcula_moda(matriz_local, moda_local, lin, col_proc);

    // Envia os resultados de volta para o processo 0
    if (rank != 0) {
        MPI_Send(moda_local, col_proc, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD);
        MPI_Send(matriz_local, col_proc * lin, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD);
        //printf("Processo %d\n", rank);    
    } else {
        // Recebe os resultados dos outros processos
        for (i = 0; i < col_proc; i++) {
            moda[i] = moda_local[i];
        }
        for (i = 0; i < col_proc * lin; i++) {
            matriz[i] = matriz_local[i];
        }
        for (i = 1; i < processos; i++) {
            MPI_Recv(moda_local, col_proc, MPI_DOUBLE, i, 0, MPI_COMM_WORLD, &status);
            MPI_Recv(matriz_local, col_proc * lin, MPI_DOUBLE, i, 0, MPI_COMM_WORLD, &status);
            k = 0;
            for (j = col_proc * i; j < col_proc * (i + 1); j++) {
                moda[j] = moda_local[k];
                k++;
            }
            k = 0;
            for (j = col_proc * lin * i; j < col_proc * lin * (i + 1); j++) {
                matriz[j] = matriz_local[k];
                k++;
            }
        }

        // Calcula as estatísticas
        calcula_media(matriz, media, lin, col);
        calcula_media_harmonica(matriz, media_har, lin, col);
        calcula_mediana(matriz, mediana, lin, col);
        calcula_variancia(matriz, media, variancia, lin, col);
        calcula_desvio_padrao(variancia, dp, col);
        calcula_coeficiente_variacao(media, dp, cv, col);

        end_time = omp_get_wtime();
        printf("%f\n", end_time - start_time);
/*
        // Imprime os resultados
        printf("\n-MÉDIA- \n");
        for (i = 0; i < col; i++)
            printf("%.1lf\n", media[i]);

        printf("\n-MÉDIA HARMÔNICA- \n");
        for (i = 0; i < col; i++)
            printf("%.1lf\n", media_har[i]);

        printf("\n-MEDIANA- \n");
        for (i = 0; i < col; i++)
            printf("%.1lf\n", mediana[i]);

        printf("\n-MODA- \n");
        for (i = 0; i < col; i++)
            printf("%.1lf\n", moda[i]);

        printf("\n-VARIÂNCIA- \n");
        for (i = 0; i < col; i++)
            printf("%.1lf\n", variancia[i]);

        printf("\n-DESVIO PADRÃO- \n");
        for (i = 0; i < col; i++)
            printf("%.1lf\n", dp[i]);

        printf("\n-COEFICIENTE DE VARIÂNCIA- \n");
        for (i = 0; i < col; i++)
            printf("%.1lf\n", cv[i]);
*/

        // Libera a memória
        free(matriz);
        free(media);
        free(media_har);
        free(mediana);
        free(moda);
        free(variancia);
        free(dp);
        free(cv);
    }

    MPI_Finalize();
}
