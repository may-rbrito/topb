#!/bin/bash
declare -a times

iterations=5
ten_percent_index=$iterations/5

for ((i = 1; i <= iterations; i++)); do
    raw_output=$(./$1)

    parsed_output=$(echo $raw_output | grep -o -E '[0-9]+.[0-9]+')

    times[$i]=$parsed_output
done

# echo "${times[@]}"

asc_sorted_times=($(printf '%s\n' "${times[@]}" | sort -n))
desc_sorted_times=($(printf '%s\n' "${times[@]}" | sort -nr))

echo "Benchmarking ./$1 with $iterations executions"

###################################################
# Average
###################################################

count=0
total=0
for t in "${asc_sorted_times[@]}"; do
    total=$(awk "BEGIN {print $total + $t; exit}")
    count=$((count + 1))
done

average=$(awk "BEGIN {print $total / $count; exit}")
echo "Average: $average seconds"

###################################################
# Top 10% faster
###################################################

top_ten_percent_faster=("${asc_sorted_times[@]:0:$ten_percent_index}")

count=0
total_top_ten_faster=0
for t in "${top_ten_percent_faster[@]}"; do
    total_top_ten_faster=$(awk "BEGIN {print $total_top_ten_faster + $t; exit}")
    count=$((count + 1))
done

top_ten_percent_faster_average=$(awk "BEGIN {print $total_top_ten_faster / $count; exit}")
echo "Top 10% faster: $top_ten_percent_faster_average seconds"

###################################################
# Top 10% slower
###################################################

top_ten_percent_slower=("${desc_sorted_times[@]:0:$ten_percent_index}")

count=0
total_top_ten_slower=0
for t in "${top_ten_percent_slower[@]}"; do
    total_top_ten_slower=$(awk "BEGIN {print $total_top_ten_slower + $t; exit}")
    count=$((count + 1))
done

top_ten_percent_slower_average=$(awk "BEGIN {print $total_top_ten_slower / $count; exit}")
echo "Top 10% slower: $top_ten_percent_slower_average seconds"

###################################################
# Standard deviation
###################################################

count=0
total=0
for t in "${asc_sorted_times[@]}"; do
    total=$(awk "BEGIN {print $total + ($t - $average)^2; exit}")
    count=$((count + 1))
done

standard_deviation=$(awk "BEGIN {print sqrt($total / $count); exit}")

echo "Standard deviation: $standard_deviation seconds"