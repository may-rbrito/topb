#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <sys/time.h>
#include <omp.h>

//gcc -fopenmp Comp.c -o Comp -lm

void bubble_sort(double *matriz, int tam) {
    int i, j;
    double aux;

    for (i = tam - 1; i > 0; i--) {
        for (j = 0; j < i; j++) {
            if (matriz[j] > matriz[j + 1]) {
                aux = matriz[j];
                matriz[j] = matriz[j + 1];
                matriz[j + 1] = aux;
            }
        }
    }
}

void ordena_colunas(double *matriz, int lin, int col) {
    int i;

    #pragma omp parallel for num_threads(8)
    for (i = 0; i < col; i++) {
        bubble_sort(&matriz[i * lin], lin);
    }
}

void calcula_media(double *matriz, double *vet,int lin, int col){
    int i,j;
    double soma;
    for(i=0;i<col;i++){
        soma=0;
        for(j=0;j<lin;j++){
            soma+=matriz[i*lin+j];
        vet[i]=soma/lin; 
        }
    }   
}

void calcula_media_harmonica(double *matriz, double *vet,int lin, int col){
    int i,j;
    double soma;
    for(i=0;i<col;i++){
        soma=0;
        for(j=0;j<lin;j++){
            soma+=(1/(matriz[i*lin+j]));
        }
        vet[i]=lin/soma; 
    }   
}

void calcula_mediana(double *matriz, double *vet, int lin, int col) {  
    int i;
    for (i = 0; i < col; i++) {
        if (lin % 2 == 0) {
            // Se o número de linhas for par, calcula a média dos dois valores do meio
            int meio1 = lin / 2 - 1;
            int meio2 = lin / 2;
            vet[i] = (matriz[i * lin + meio1] + matriz[i * lin + meio2]) / 2;
        } else {
            // Se o número de linhas for ímpar, pega o valor do meio
            int meio = lin / 2;
            vet[i] = matriz[i * lin + meio];
        }
    }
}

//Adaptado de https://www.clubedohardware.com.br/forums/topic/1291570-programa-em-c-que-calcula-moda-media-e-mediana/
double moda_aux(double *matriz,int lin){
    int i, j; 
    double *cont;
    cont=(double*)malloc(lin*sizeof(double));
	float conta=0, moda=0;
	
	for(i=0;i<lin;i++){
        for(j=i+1;j<lin;j++){
        	
			if(matriz[i]==matriz[j]){
				cont[i]++;
					if(cont[i]>conta){
						conta=cont[i];
						moda=matriz[i];
					}
			}

        }
        cont[i]=0;
    }
    free(cont);
    if(conta == 0){
    	return -1;
	}
	else{
		return moda;
	}

}

void calcula_moda(double *matriz,double *moda,int lin, int col){
    int i;

    #pragma omp parallel for num_threads(8)
    for(i=0;i<col;i++){
        moda[i]=moda_aux(matriz+(i*lin),lin);
    }
}

void calcula_variancia(double *matriz, double *media,double *variancia, int lin, int col){
    int i,j;
    double soma;
    for(i=0;i<col;i++){
        soma=0;
        for(j=0;j<lin;j++){
            soma+=pow((matriz[i*lin+j]-media[i]),2);
        }
        variancia[i]=soma/(lin-1); 
    } 
}

void calcula_desvio_padrao(double *variancia,double *dp, int col){
    int i;
    for(i=0;i<col;i++){
        dp[i]=sqrt(variancia[i]);
    }  
}

void calcula_coeficiente_variacao(double *media,double *dp,double *cv, int col){
    int i;
    for(i=0;i<col;i++){
        cv[i]=dp[i]/media[i];
    }  
}

int main(int argc,char **argv){

    FILE *arquivo = fopen("input", "r");

    int lin,col,i,j; // Define as variáveis de índices e dimensões
    double *matriz,*mediana,*media,*media_har,*moda,*variancia,*dp,*cv; // Define a matriz (forma linear), vetores de medidas estatísticas

    fscanf(arquivo, "%d ", &lin); // Lê a quantidade de linhas da matriz
    fscanf(arquivo, "%d\n", &col); // Lê a quantidade de colunas da matriz
    
    // Alocações
    matriz=(double *)malloc(lin*col * sizeof(double)); // Aloca a matriz
    media=(double *)malloc(col * sizeof(double)); // Aloca o vetor de media
    media_har=(double *)malloc(col * sizeof(double)); // Aloca o vetor de media harmônica
    mediana=(double *)malloc(col * sizeof(double)); // Aloca o vetor de mediana
    moda=(double *)malloc(col * sizeof(double)); // Aloca o vetor de moda
    variancia=(double *)malloc(col * sizeof(double)); // Aloca o vetor de variância
    cv=(double *)malloc(col * sizeof(double)); // Aloca o vetor de coeficiente de variação
    dp=(double *)malloc(col * sizeof(double)); // Aloca o vetor de desvio padrão

 
    for(i=0;i<lin;i++){
        //printf("\n");
        for(j=0;j<col;j++){
            fscanf(arquivo, "%lf ",&(matriz[j*lin+i])); // Lê os dados transpostos em uma matriz de entrada
            //printf("  %f  ",matriz[j*lin+i]);
        }
    }
    //printf("\n");

    double start_time, end_time;
    start_time = omp_get_wtime();

    calcula_media(matriz,media,lin,col);
    calcula_media_harmonica(matriz,media_har,lin,col);
    ordena_colunas(matriz,lin,col);
    calcula_mediana(matriz,mediana,lin,col);
    calcula_moda(matriz,moda,lin,col);
    calcula_variancia(matriz,media,variancia,lin,col);
    calcula_desvio_padrao(variancia,dp,col);
    calcula_coeficiente_variacao(media,dp,cv,col);

    end_time = omp_get_wtime();
    printf("%f\n", end_time - start_time);

/*
    printf("\n-MÉDIA- \n");
    for (i = 0; i < col; i++)
        printf("%.1lf\n", media[i]);

    printf("\n-MÉDIA HARMÔNICA- \n");
    for (i = 0; i < col; i++)
        printf("%.1lf\n", media_har[i]);

    printf("\n-MODA- \n");
    for (i = 0; i < col; i++)
        printf("%.1lf\n", moda[i]);

    printf("\n-MEDIANA- \n");
    for (i = 0; i < col; i++)
        printf("%.1lf\n", mediana[i]);
        
    printf("\n-VARIÂNCIA- \n");
    for (i = 0; i < col; i++)
        printf("%.1lf\n", variancia[i]);

    printf("\n-DESVIO PADRÃO- \n");
    for (i = 0; i < col; i++)
        printf("%.1lf\n", dp[i]);

    printf("\n-COEFICIENTE DE VARIÂNCIA- \n");
    for (i = 0; i < col; i++)
        printf("%.1lf\n", cv[i]);
*/


    // Desaloca memória
    free(matriz);
    free(media);
    free(media_har);
    free(mediana);
    free(moda);
    free(variancia);
    free(dp);
    free(cv);
}
